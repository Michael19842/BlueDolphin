$Script:_Settings = Get-Content "$PSScriptRoot\Settings.json" -raw | Convertfrom-json
