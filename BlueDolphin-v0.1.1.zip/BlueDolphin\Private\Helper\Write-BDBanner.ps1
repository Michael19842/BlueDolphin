function Write-BDBanner {
    write-color @'
{blue}/+++//-.                         
{blue}`-/oooooo++///////:-.            
{blue}  -ooooooooooooooooo+:          
{blue}  `/ooooooooooooooooooo/`
{blue} .+ooooooooooooooooooooo+:`
{blue}`+ooooooooooooooo////++ooo+`
{blue}-oooooooooo/-+oo-      ``.`
{blue}:oooooooo+- `++-                 
{blue}:oooooooo-   `` {DarkGray}______ _             ______      _       _     _   
{blue}.ooooooo+       {DarkGray}| ___ \ |            |  _  \    | |     | |   (_)               
{blue}/oooooo+        {DarkGray}| |_/ / |_   _  ___  | | | |___ | |_ __ | |__  _ _ __                 
{blue} /ooooo+        {DarkGray}| ___ \ | | | |/ _ \ | | | / _ \| | '_ \| '_ \| | '_ \                
{blue}  /ooooo/`      {DarkGray}| |_/ / | |_| |  __/ | |/ / (_) | | |_) | | | | | | | |
{blue}    .+ooooo++//-{DarkGray}\____/|_|\__,_|\___| |___/ \___/|_| .__/|_| |_|_|_| |_|                
{blue}      +oooooo/--`  {white}PowerShell module 1.0 (2019)   {DarkGray}| | 
{blue}     -ooo+```      {white}OData Intergration Module      {DarkGray}|_|  
{blue}    /oo:                        
{blue}    :+- 
'@
}